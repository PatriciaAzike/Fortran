
.. role:: bolditalic
   :class: bolditalic